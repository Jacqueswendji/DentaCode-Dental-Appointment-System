const Patient=require('../models/Patient');
const Appointment=require('../models/Appointment');
const crud=require('./crudFactory');
module.exports=crud(Patient,['firstName','lastName','email','phone','dateOfBirth'],{
 title:'Patient',
 beforeRemove:async id=>(await Appointment.exists({patient:id}))?{status:409,message:'Patient has appointments; remove or reassign them first'}:null
});
