const mongoose=require('mongoose');
// Shared MVC controller helper: whitelist fields, validate IDs and MongoDB errors.
module.exports=function crudFactory(Model,fields,options={}){
 const title=options.title||Model.modelName;
 const invalid=(res)=>res.status(400).json({message:'Invalid ID'});
 const fail=(res,e)=>res.status(['ValidationError','CastError'].includes(e.name)?400:500).json({message:['ValidationError','CastError'].includes(e.name)?'Invalid data':`${title} operation failed`});
 const pick=(body)=>Object.fromEntries(fields.filter(k=>Object.prototype.hasOwnProperty.call(body||{},k)).map(k=>[k,body[k]]));
 const query=()=>options.populate?Model.find().populate(options.populate):Model.find();
 return {
  list:async(req,res)=>{try{res.json(await query().sort({createdAt:-1}));}catch(e){fail(res,e);}},
  get:async(req,res)=>{if(!mongoose.isValidObjectId(req.params.id))return invalid(res);try{let q=Model.findById(req.params.id);if(options.populate)q=q.populate(options.populate);const item=await q;return item?res.json(item):res.status(404).json({message:`${title} not found`});}catch(e){fail(res,e);}},
  create:async(req,res)=>{try{const body=pick(req.body);if(options.validate){const error=await options.validate(body);if(error)return res.status(error.status||400).json({message:error.message});}res.status(201).json(await Model.create(body));}catch(e){fail(res,e);}},
  update:async(req,res)=>{if(!mongoose.isValidObjectId(req.params.id))return invalid(res);const body=req.body||{};if(!Object.keys(body).length||Object.keys(body).some(k=>!fields.includes(k)))return res.status(400).json({message:'Invalid update fields'});try{const changes=pick(body);if(options.validate){const error=await options.validate(changes);if(error)return res.status(error.status||400).json({message:error.message});}const item=await Model.findByIdAndUpdate(req.params.id,{$set:changes},{new:true,runValidators:true});return item?res.json(item):res.status(404).json({message:`${title} not found`});}catch(e){fail(res,e);}},
  remove:async(req,res)=>{if(!mongoose.isValidObjectId(req.params.id))return invalid(res);try{if(options.beforeRemove){const error=await options.beforeRemove(req.params.id);if(error)return res.status(error.status||409).json({message:error.message});}const item=await Model.findByIdAndDelete(req.params.id);return item?res.json({message:`${title} deleted successfully`,id:item.id}):res.status(404).json({message:`${title} not found`});}catch(e){fail(res,e);}}
 };
};
