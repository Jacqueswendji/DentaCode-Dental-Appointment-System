# DentaCode — 02 Almansur Nurtazin

GitHub: `ALMANSUR130508`  
Responsibility: Database and patient management

## Files assigned to you
- `backend/models/Patient.js`
- `backend/controllers/crudFactory.js`
- `backend/controllers/patientController.js`
- `backend/routes/patientRoutes.js`

## Your actual work before committing
1. Accept your GitHub invitation and clone the team repository.
2. Review your assigned files; understand and adjust them as needed.
3. Compare against existing repository files before copying: do not overwrite someone else's changes.
4. Run relevant checks and tests; record what actually passed.
5. Commit ONLY your verified contribution using your own GitHub identity.
6. Update your Agile task and help with the team demo.

**These files are prepared starter contributions, not evidence that you personally authored or tested them.**

## English presentation script (adapt after your actual work)

I am Almansur Nurtazin. My responsibility is the database and patient management. The Patient model defines fields such as first name, last name, email and phone. The patient controller and routes support creating, listing, updating and deleting patients. I will demonstrate a patient record in MongoDB and explain how the Express API handles validation.
