const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const User = require('../models/User');
const publicFields = 'name email role createdAt updatedAt';
const validId = id => mongoose.isValidObjectId(id);
const fail = (res, error, message) => {
  if (error.code === 11000) return res.status(409).json({ message: 'Email already registered' });
  if (error.name === 'ValidationError' || error.name === 'CastError') return res.status(400).json({ message: 'Invalid user data' });
  return res.status(500).json({ message });
};
exports.me = async (req, res) => {
  try {
    const user = await User.findById(req.user.id).select(publicFields);
    if (!user) return res.status(401).json({ message: 'User not found' });
    res.json(user);
  } catch (error) { fail(res, error, 'Failed to retrieve profile'); }
};
exports.list = async (req, res) => {
  try { res.json(await User.find().select(publicFields).sort({ createdAt: -1 })); }
  catch (error) { fail(res, error, 'Failed to retrieve users'); }
};
exports.get = async (req, res) => {
  if (!validId(req.params.id)) return res.status(400).json({ message: 'Invalid user ID' });
  try {
    const user = await User.findById(req.params.id).select(publicFields);
    if (!user) return res.status(404).json({ message: 'User not found' });
    res.json(user);
  } catch (error) { fail(res, error, 'Failed to retrieve user'); }
};
exports.create = async (req, res) => {
  const { name, email, password, role = 'staff' } = req.body || {};
  if (typeof name !== 'string' || !name.trim() || typeof email !== 'string' || !email.trim() ||
      typeof password !== 'string' || password.length < 8 || Buffer.byteLength(password, 'utf8') > 72 ||
      !['admin','staff'].includes(role)) return res.status(400).json({ message: 'Invalid user data' });
  try {
    const user = await User.create({ name: name.trim(), email: email.trim().toLowerCase(),
      password: await bcrypt.hash(password, 12), role });
    res.status(201).json({ id: user.id, name: user.name, email: user.email, role: user.role });
  } catch (error) { fail(res, error, 'Failed to create user'); }
};
exports.update = async (req, res) => {
  const { id } = req.params;
  if (!validId(id)) return res.status(400).json({ message: 'Invalid user ID' });
  const body = req.body || {};
  const keys = Object.keys(body);
  if (!keys.length || keys.some(k => !['name','email','role'].includes(k)))
    return res.status(400).json({ message: 'Only name, email and role may be updated' });
  if ('name' in body && (typeof body.name !== 'string' || !body.name.trim()) ||
      'email' in body && (typeof body.email !== 'string' || !body.email.trim()) ||
      'role' in body && !['admin','staff'].includes(body.role))
    return res.status(400).json({ message: 'Invalid user data' });
  if (id === req.user.id && body.role === 'staff')
    return res.status(400).json({ message: 'Cannot demote your own admin account' });
  const changes = {};
  if ('name' in body) changes.name = body.name.trim();
  if ('email' in body) changes.email = body.email.trim().toLowerCase();
  if ('role' in body) changes.role = body.role;
  try {
    const user = await User.findByIdAndUpdate(id, { $set: changes },
      { new: true, runValidators: true }).select(publicFields);
    if (!user) return res.status(404).json({ message: 'User not found' });
    res.json(user);
  } catch (error) { fail(res, error, 'Failed to update user'); }
};
exports.remove = async (req, res) => {
  const { id } = req.params;
  if (!validId(id)) return res.status(400).json({ message: 'Invalid user ID' });
  if (id === req.user.id) return res.status(400).json({ message: 'Cannot delete your own account' });
  try {
    const user = await User.findById(id);
    if (!user) return res.status(404).json({ message: 'User not found' });
    if (user.role === 'admin' && await User.countDocuments({ role: 'admin' }) <= 1)
      return res.status(409).json({ message: 'Cannot delete the last administrator' });
    await user.deleteOne();
    res.json({ message: 'User deleted successfully', userId: id });
  } catch (error) { fail(res, error, 'Failed to delete user'); }
};
