module.exports=function requireRole(...roles){
 return (req,res,next)=>req.user&&roles.includes(req.user.role)?next():res.status(403).json({message:'Access denied: insufficient permissions'});
};
