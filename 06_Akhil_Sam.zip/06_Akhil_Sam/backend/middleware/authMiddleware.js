const jwt=require('jsonwebtoken');
const User=require('../models/User');
module.exports=async function authMiddleware(req,res,next){
 const match=/^Bearer (.+)$/i.exec(req.headers.authorization||'');
 if(!match)return res.status(401).json({message:'Authentication required'});
 try{
  if(!process.env.JWT_SECRET)return res.status(500).json({message:'Authentication configuration missing'});
  const payload=jwt.verify(match[1],process.env.JWT_SECRET,{algorithms:['HS256']});
  const user=await User.findById(payload.id);
  if(!user)return res.status(401).json({message:'User no longer exists'});
  req.user={id:user.id,role:user.role};next();
 }catch(e){if(['JsonWebTokenError','TokenExpiredError','NotBeforeError','CastError'].includes(e.name))return res.status(401).json({message:'Invalid or expired token'});next(e);}
};
