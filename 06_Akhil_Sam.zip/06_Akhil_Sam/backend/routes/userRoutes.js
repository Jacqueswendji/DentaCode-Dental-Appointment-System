const router=require('express').Router();
const auth=require('../middleware/authMiddleware');
const role=require('../middleware/roleMiddleware');
const c=require('../controllers/userController');
router.use(auth);router.get('/me',c.me);
router.use(role('admin'));
router.get('/',c.list);router.post('/',c.create);router.get('/:id',c.get);
router.put('/:id',c.update);router.delete('/:id',c.remove);
module.exports=router;
