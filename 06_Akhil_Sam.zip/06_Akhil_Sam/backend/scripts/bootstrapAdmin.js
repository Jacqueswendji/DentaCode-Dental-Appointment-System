// Run intentionally, once, from backend folder: node scripts/bootstrapAdmin.js <email>
// Promotes an existing staff user ONLY if there are currently no administrators.
require('dotenv').config();
const mongoose = require('mongoose');
const User = require('../models/User');
(async () => {
  const email = process.argv[2]?.trim().toLowerCase();
  if (!email || !process.env.MONGO_URI) throw Error('Provide existing email and configure MONGO_URI');
  await mongoose.connect(process.env.MONGO_URI);
  if (await User.countDocuments({ role: 'admin' }) !== 0) throw Error('Admin already exists; no changes made');
  const user = await User.findOne({ email });
  if (!user) throw Error('User not found; register the account first');
  user.role = 'admin';
  await user.save();
  console.log('First admin assigned:', user.email);
})().catch(e => { console.error(e.message); process.exitCode = 1; })
  .finally(() => mongoose.disconnect());
