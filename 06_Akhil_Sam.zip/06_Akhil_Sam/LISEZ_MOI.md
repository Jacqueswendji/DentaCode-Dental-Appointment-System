# DentaCode — 06 Akhil Sam

GitHub: `akhilsam9989-rgb`  
Responsibility: Security, users and API tests

## Files assigned to you
- `backend/middleware/authMiddleware.js`
- `backend/middleware/roleMiddleware.js`
- `backend/controllers/userController.js`
- `backend/routes/userRoutes.js`
- `backend/scripts/bootstrapAdmin.js`
- `tests/test-api.ps1`
- `tests/test-crud.ps1`

## Your actual work before committing
1. Accept your GitHub invitation and clone the team repository.
2. Review your assigned files; understand and adjust them as needed.
3. Compare against existing repository files before copying: do not overwrite someone else's changes.
4. Run relevant checks and tests; record what actually passed.
5. Commit ONLY your verified contribution using your own GitHub identity.
6. Update your Agile task and help with the team demo.

**These files are prepared starter contributions, not evidence that you personally authored or tested them.**

## English presentation script (adapt after your actual work)

I am Akhil Sam. I am responsible for security, user management and API testing. Authentication middleware verifies the JWT and loads the current user. Role middleware restricts administrative endpoints. Our PowerShell tests check unauthorized requests, staff permissions and CRUD endpoints. I will explain why a staff member receives HTTP 403 when trying to list all users.
