param([string]$BaseUrl='http://127.0.0.1:5000')
$ErrorActionPreference='Stop'
$failed=0
function Check($label,$method,$url,$expected,$headers=@{},$body=$null){
 $params=@{Uri=$url;Method=$method;Headers=$headers;UseBasicParsing=$true;ErrorAction='Stop'}
 if($null -ne $body){$params.Body=($body|ConvertTo-Json -Depth 8);$params.ContentType='application/json'}
 try{$status=[int](Invoke-WebRequest @params).StatusCode}
 catch{if($_.Exception.Response){$status=[int]$_.Exception.Response.StatusCode}else{throw}}
 if($status -eq $expected){Write-Host "PASS - $label - HTTP $status"}else{Write-Host "FAIL - $label - expected $expected, got $status";$script:failed++}
}
Check 'Health' GET "$BaseUrl/api/health" 200
foreach($endpoint in @('patients','dentists','appointments','users')){Check "$endpoint without JWT" GET "$BaseUrl/api/$endpoint" 401}
$email=Read-Host 'Existing staff account email'
$secure=Read-Host 'Password' -AsSecureString
$ptr=[Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
try{$password=[Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr)}finally{[Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr)}
try{$login=Invoke-RestMethod -Uri "$BaseUrl/api/auth/login" -Method POST -ContentType 'application/json' -Body (@{email=$email;password=$password}|ConvertTo-Json)}finally{$password=$null}
if(-not $login.token){throw 'Login did not return JWT'}
$h=@{Authorization="Bearer $($login.token)"}
Check 'Own profile' GET "$BaseUrl/api/users/me" 200 $h
foreach($endpoint in @('patients','dentists','appointments')){Check "$endpoint with JWT" GET "$BaseUrl/api/$endpoint" 200 $h}
if($login.role -eq 'staff'){Check 'Staff blocked from admin user list' GET "$BaseUrl/api/users" 403 $h}
if($login.role -eq 'admin'){Check 'Admin can list users' GET "$BaseUrl/api/users" 200 $h}
Write-Host "FAILED TESTS: $failed";if($failed){exit 1}
