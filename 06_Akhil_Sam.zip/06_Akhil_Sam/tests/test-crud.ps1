param([string]$BaseUrl='http://127.0.0.1:5000')
$ErrorActionPreference='Stop'
$email=Read-Host 'Staff account email';$secret=Read-Host 'Password' -AsSecureString
$ptr=[Runtime.InteropServices.Marshal]::SecureStringToBSTR($secret)
try{$password=[Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr)}finally{[Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr)}
try{$login=Invoke-RestMethod "$BaseUrl/api/auth/login" -Method POST -ContentType 'application/json' -Body (@{email=$email;password=$password}|ConvertTo-Json)}finally{$password=$null}
$h=@{Authorization="Bearer $($login.token)"};$patient=$null;$dentist=$null;$appointment=$null
function Api($path,$method='GET',$body=$null){$p=@{Uri="$BaseUrl/api/$path";Method=$method;Headers=$h;ErrorAction='Stop'};if($null -ne $body){$p.ContentType='application/json';$p.Body=$body|ConvertTo-Json};Invoke-RestMethod @p}
try{
 $suffix=[guid]::NewGuid().ToString('N').Substring(0,10)
 $patient=Api 'patients' 'POST' @{firstName='Test';lastName='Patient';email="patient.$suffix@example.com";phone='4165550100'}
 $dentist=Api 'dentists' 'POST' @{firstName='Test';lastName='Dentist';email="dentist.$suffix@example.com";specialty='General'}
 $appointment=Api 'appointments' 'POST' @{patient=$patient._id;dentist=$dentist._id;appointmentDate='2026-12-01T15:00:00Z';reason='API test'}
 $null=Api "patients/$($patient._id)" 'PUT' @{phone='4165550199'}
 $null=Api "dentists/$($dentist._id)" 'PUT' @{specialty='Orthodontics'}
 $null=Api "appointments/$($appointment._id)" 'PUT' @{status='completed'}
 if((Api "patients/$($patient._id)").phone -ne '4165550199'){throw 'Patient UPDATE failed'}
 if((Api "dentists/$($dentist._id)").specialty -ne 'Orthodontics'){throw 'Dentist UPDATE failed'}
 if((Api "appointments/$($appointment._id)").status -ne 'completed'){throw 'Appointment UPDATE failed'}
 Write-Host 'PASS - Create, Read, Update across three collections'
}finally{
 if($appointment){$null=Api "appointments/$($appointment._id)" 'DELETE'}
 if($patient){$null=Api "patients/$($patient._id)" 'DELETE'}
 if($dentist){$null=Api "dentists/$($dentist._id)" 'DELETE'}
 Write-Host 'Temporary records cleanup attempted'
}
